const BTN_TAGNAME = "span";
const BTN_DATANAME = "data-index";
const CHEACKED_CLASSNAME = "active";

export { BTN_TAGNAME, BTN_DATANAME, CHEACKED_CLASSNAME };
